# Alpha Campaign 2 — Pre-Registration (FROZEN before testing)

**Registered:** 2026-06-19, before any Campaign 2 backtest is run.
**Scope (fixed):** only **session-effect**, **cross-asset**, and **regime-transition** hypotheses.
**Validation thresholds: UNCHANGED from Campaign 1** — DSR ≥ 0.95 (trials-deflated over the full
Campaign-2 set), PBO < 0.50, White's Reality Check p < 0.05, Walk-Forward status = PASSED
(min OOS stability ≥ 0.5), Expected Value > 0 net of costs, documented economic mechanism required.
No threshold weakening, no manual intervention, no survivorship bias (every candidate reported),
no overfitting exceptions, no scope expansion mid-campaign.

## Design rationale — why this set should have a higher survival probability than Campaign 1
Campaign 1's failure mode was **cost domination of high-turnover H1 rules** (every candidate
negative net of 3 bps/turnover; Reality-Check p = 0.694). Campaign 2 attacks that directly,
**without touching thresholds**:
1. **Lower turnover** — session strategies trade ≤ once per session; cross-asset and regime
   strategies operate on **D1 bars**. Fewer turnovers ⇒ costs cannot erase the edge.
2. **Genuine independent information** — cross-asset hypotheses use a *second* instrument's signal,
   not another transform of the same price (real new information, lower correlation to existing).
3. **Stronger economic priors** — each hypothesis has a structural/risk-premium/liquidity mechanism,
   not a pure price-pattern.
4. **More history** — request maximum available D1 bars (target ≥ 3000 D1 ≈ 12 years) so DSR and
   walk-forward have real statistical power.

## Data
- Timeframe: **D1** for cross-asset and regime-transition; **H1 with bar-hour** for session effects.
- Instruments (subject to terminal availability; unavailable symbols are reported as skipped, not
  substituted): EURUSD, GBPUSD, USDJPY, AUDJPY, XAUUSD, US500, USDCAD, and a USD index (DXY/USDX)
  or, if absent, a documented USD-basket proxy fixed in advance.
- Costs: pessimistic, unchanged methodology (per-turnover friction; D1 turnover is far lower).

## Pre-registered hypotheses (frozen parameters)

### Session effects (H1 bars, bar-hour gated; ≤ 1 entry/session)
| ID | Instrument | Rule (frozen) | Mechanism |
|----|-----------|---------------|-----------|
| S1 `london_open_momentum` | EURUSD | direction of first London hour (08:00 server) held to session close | liquidity/order-flow concentration (structural) |
| S2 `ny_open_continuation` | US500 | sign of first NY hour (14:30 server) return held 4h | behavioral/structural drift |
| S3 `asian_range_breakout` | XAUUSD | break of Asian-session (00:00–07:00) hi/lo during London, held to NY close | structural liquidity |

### Cross-asset (D1)
| ID | Instruments | Rule (frozen) | Mechanism |
|----|-------------|---------------|-----------|
| X1 `dxy_lead_eurusd` | DXY→EURUSD | yesterday's DXY return sign ⇒ today EURUSD opposite | structural USD transmission |
| X2 `usd_strength_gold` | DXY→XAUUSD | yesterday's DXY return sign ⇒ today XAUUSD opposite | risk-premium / USD numeraire |
| X3 `riskon_transmission` | US500→AUDJPY | yesterday's US500 up/down ⇒ today AUDJPY same direction | risk-on/off transmission |

### Regime transition (D1)
| ID | Instrument | Rule (frozen) | Mechanism |
|----|-----------|---------------|-----------|
| R1 `vol_regime_onset_trend` | EURUSD | on low→high realized-vol transition, follow 20D trend | regime persistence after break (structural) |
| R2 `range_to_trend_breakout` | XAUUSD | on ADX range→trend transition, follow Donchian-20 breakout | behavioral underreaction to regime change |
| R3 `post_crisis_reversion` | US500 | after a vol spike subsides (vol falls back below median), fade the prior move 5D | liquidity / inventory recovery |

**Total: 9 candidates** (× any multi-symbol expansion is NOT permitted mid-campaign).
`n_trials` for DSR deflation = the final candidate count actually tested.

## Frozen parameters
- Trend lookback 20; Donchian window 20; vol window 20 (D1); ADX window 14; vol-regime split at the
  in-sample median; session hours in **broker-server time** (FusionMarkets-Demo).
- All parameters fixed here; no optimization, no per-symbol tuning.

## Survivor definition (identical to Campaign 1)
A candidate survives iff it passes ALL: EV > 0 (net), Walk-Forward PASSED, DSR ≥ 0.95, White's
Reality-Check significant at 5%, PBO acceptable (< 0.50). Survivors (if any) move to **Shadow
Deployment + Paper Trading only** — never live capital in this campaign.

## Execution note
Running Campaign 2 requires wiring D1 + bar-hour + multi-symbol (DXY/second-instrument) feeds into
the strategy layer (the cross-asset rules need two symbols' bars aligned by date). That harness is
the Campaign-2 implementation step; this document is the immutable pre-registration that precedes it.
