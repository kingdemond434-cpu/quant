"""Covariance helpers for the portfolio engine."""

from __future__ import annotations

from collections.abc import Sequence
from typing import cast

import numpy as np

from libs.portfolio.errors import PortfolioError
from libs.portfolio.models import AlphaInput


def covariance_from_alphas(
    alphas: Sequence[AlphaInput], correlation: np.ndarray | None = None
) -> np.ndarray:
    """Build a covariance matrix from per-alpha volatilities and an optional correlation matrix."""
    vols = np.array([a.volatility for a in alphas], dtype="float64")
    n = len(vols)
    if n == 0:
        raise PortfolioError("at least one alpha is required")
    if correlation is None:
        return cast("np.ndarray", np.diag(vols**2))
    corr = np.asarray(correlation, dtype="float64")
    if corr.shape != (n, n):
        raise PortfolioError(f"correlation shape {corr.shape} != ({n}, {n})")
    return cast("np.ndarray", np.outer(vols, vols) * corr)


def cov_to_corr(cov: np.ndarray) -> np.ndarray:
    """Convert a covariance matrix to a correlation matrix."""
    std = np.sqrt(np.diag(cov))
    std_safe = np.where(std > 0, std, 1.0)
    corr = cov / np.outer(std_safe, std_safe)
    np.fill_diagonal(corr, 1.0)
    return cast("np.ndarray", corr)
